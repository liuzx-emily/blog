#!/usr/bin/env node
import { readFile } from "node:fs/promises";
import process from "node:process";
import { greenLog, redLog } from "./utils.js";

greenLog("\n【commit-msg】校验 message...");

// 用来编辑 commit message 的临时文件的地址
const tempFilePath = process.argv[2];

// 预设 message
let message = await readFile(tempFilePath, { encoding: "utf-8" });

message = message.trim();

if (message === "pass") {
  greenLog("\ncommit message 合规，继续 commit 进程。");
  process.exit(0);
} else {
  redLog(`\ncommit message 不合规，中止 commit 进程。message 内容为：\n`);
  console.log(message);
  process.exit(1); // exit non-zero can halt commit process
}
