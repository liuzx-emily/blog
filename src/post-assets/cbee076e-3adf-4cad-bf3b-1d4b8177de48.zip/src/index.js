export const message = "hello";
let info;
