export var num = 2;
var num2;
