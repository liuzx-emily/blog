const num1 = 1;
num2 = 2;
