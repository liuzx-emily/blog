import process from "node:process";
import simpleGit from "simple-git";
import { ESLint } from "eslint";
import chalk from "chalk";

console.log("Enter my lint-staged process!\n");

async function getStagedFiles() {
  try {
    // get staged files
    const git = simpleGit();
    const stagedFiles = await git.status().then((status) => status.staged);
    // lint staged files
    const eslint = new ESLint({ fix: true });
    const { filesHavingErrors } = await lintAndFix(eslint, stagedFiles);
    if (filesHavingErrors.length > 0) {
      outputLintingErrors(filesHavingErrors);
      process.exit(1);
    } else {
      console.log("No linting errors found.");
      process.exit(0);
    }
  } catch (error) {
    console.error("Error getting staged files:", error);
    process.exit(1);
  }
}

getStagedFiles();

async function lintAndFix(eslint, filePaths) {
  const lintResults = await eslint.lintFiles(filePaths);
  const filesHavingErrors = lintResults.filter((result) => result.errorCount > 0);
  return { lintResults, filesHavingErrors };
}

function outputLintingErrors(filesHavingErrors) {
  const output = filesHavingErrors
    .map(({ filePath, errorCount, messages }) => {
      const errors = messages
        .filter((message) => message.severity === 2)
        .map(({ ruleId, line }) => {
          return `  [${ruleId}] at line ${line}`;
        });
      return `${chalk.red(`[${errorCount} error]`)}${filePath} \n${errors.join("\n")}`;
    })
    .join("\n");
  console.log(output);
}
