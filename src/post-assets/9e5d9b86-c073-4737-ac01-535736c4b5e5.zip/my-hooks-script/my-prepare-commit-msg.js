#!/usr/bin/env node
import { writeFile } from "node:fs/promises";
import process from "node:process";
import { greenLog } from "./utils.js";

greenLog("\n【prepare-commit-msg】预设 message 的值。");

// 用来编辑 commit message 的临时文件的地址
const tempFilePath = process.argv[2];
// 预设 message
await writeFile(tempFilePath, `# auto-generated message\n${+new Date()}`);
process.exit(0); // exit non-zero can halt commit process
