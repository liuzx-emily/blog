## 初始化

测试 hook 效果前需要先配置好环境：

```bash
# 安装依赖
npm install
# 初始化 git
git init
# 修改 hooks 目录
git config core.hooksPath my-hooks
```

## 测试 hook 效果

```bash
git add .
git commit
```
