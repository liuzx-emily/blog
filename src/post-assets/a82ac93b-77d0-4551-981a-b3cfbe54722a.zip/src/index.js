import { foo } from "./foo";
import { bar } from "./bar";

export const data = foo + bar;
