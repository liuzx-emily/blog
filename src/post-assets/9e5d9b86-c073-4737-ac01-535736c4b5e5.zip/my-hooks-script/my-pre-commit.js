#!/usr/bin/env node
import { ESLint } from "eslint";
import process from "node:process";
import simpleGit from "simple-git";
import { greenLog, redLog } from "./utils.js";

greenLog("\n【pre-commit】检查待提交的代码...");

// 注：代码只是简单示例，并不能应用于实际项目中。
// 比如用 simple-git API 获取到的 stagedFiles 也包括状态为 DELETED 的文件。应该先过滤掉这些 DELETED 的文件，不然继续执行 eslint 会出错，但是我懒得改了。

async function getStagedFiles() {
  try {
    // get staged files
    const git = simpleGit();
    const stagedFiles = await git.status().then((status) => status.staged);
    // lint staged files
    const eslint = new ESLint({ fix: true });
    const { filesHavingErrors } = await lintAndFix(eslint, stagedFiles);
    if (filesHavingErrors.length > 0) {
      outputLintingErrors(filesHavingErrors);
      redLog("\n代码中发现 linting error，中止 commit 进程。");
      process.exit(1);
    } else {
      greenLog("\n待提交的代码中未发现 linting errors，继续 commit 进程。");
      process.exit(0);
    }
  } catch (error) {
    console.error(error);
    redLog("\n未能成功获取待提交代码，中止 commit 进程。");
    process.exit(1); // exit non-zero can halt commit process
  }
}

getStagedFiles();

async function lintAndFix(eslint, filePaths) {
  const lintResults = await eslint.lintFiles(filePaths);
  const filesHavingErrors = lintResults.filter((result) => result.errorCount > 0);
  return { lintResults, filesHavingErrors };
}

function outputLintingErrors(filesHavingErrors) {
  const output = filesHavingErrors.map(({ filePath, errorCount, messages }) => {
    const errors = messages
      .filter((message) => message.severity === 2)
      .map(({ ruleId, line }) => {
        return `  [${ruleId}] at line ${line}`;
      });
    return `\n${`[${errorCount} error]`}${filePath} \n${errors.join("\n")}`;
  });
  redLog(output);
}
