export var num = 1;
