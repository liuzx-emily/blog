import moment from "moment";
import { mkdir, writeFile } from "node:fs/promises";
import path from "node:path";
import process from "node:process";
import { createRequire } from "node:module";

const packageVersion = createRequire(import.meta.url)("../package.json").version;

async function generatePages() {
  const time = moment(new Date()).format("YYYY-MM-DD HH:mm:ss");
  const htmlString = `
  <!DOCTYPE html>
  <html lang="zh-CN">
    <head><meta charset="UTF-8"></head>
    <body>
      版本 ${packageVersion} 于 ${time} 发布。
    </body>
  </html>`;

  const pagesDir = path.join(process.cwd(), "./lily-pages");
  await mkdir(pagesDir, { recursive: true });
  await writeFile(path.join(pagesDir, "index.html"), htmlString);
}

generatePages();
