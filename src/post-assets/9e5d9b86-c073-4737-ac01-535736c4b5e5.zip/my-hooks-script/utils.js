import chalk from "chalk";

export function greenLog(str) {
  console.log(chalk.green(str));
}
export function redLog(str) {
  console.log(chalk.red(str));
}
