export const foo = "foo";
